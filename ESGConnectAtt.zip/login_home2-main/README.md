Trabalho FIAP Cap 9 - Ecossistema multimídia - Atividade 2 - Plataforma ESG.
Grupo: Jayme, Igor e Raphael. Feito em kotlin com jetpack composer no android studio.
Duas telas, login e principal, acessível ao clicar no botão laranja login.
